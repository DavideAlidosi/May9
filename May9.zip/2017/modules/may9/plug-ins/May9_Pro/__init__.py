import maya.mel as mel

mel.eval('source "May9_scripts.mel"')
mel.eval('source "May9_core.mel"')